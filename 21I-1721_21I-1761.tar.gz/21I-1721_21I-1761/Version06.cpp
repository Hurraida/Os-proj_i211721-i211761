#include <SFML/Graphics.hpp>
#include <iostream>
#include <pthread.h>

using namespace std;
using namespace sf;

const int GRID_WIDTH = 28;
const int GRID_HEIGHT = 36;
const int PELLET_COUNT = 234;
int indexTracker = 0;
const int WALL_COUNT = 422;
const int TILE_SIZE = 25;
const int POWER_PELLET_COUNT = 4;
int playerLives;
int currentScore = 0;
int topScore;


bool initializePellet = false;
bool renderpelletShapes = true;
bool initializePowerPellet = false;
bool powerPelletCollected;
bool loopEntered = true;

bool blueUp = true;
bool redUp = true;
bool blueRight = true;
bool redRight = true;
bool redDown = true;
bool blueDown = true;
bool blueBooleans[13];
bool redBooleans[13];
bool blueBooleansSet = false;
bool redBooleansSet = false;


float movementSpeed = 0.2f;
float blueEnemySpeed = 0.1; 
float redEnemySpeed = 0.1; 
float timer = 0; 



void SetBlueBooleans()
{
  int i=0;
  while(i < 13)
  {
	  blueBooleans[i] = true;
	  i++;
  }
  blueBooleansSet = true;
}

void SetRedBooleans()
{
  int i=0;
  while(i < 13)
  {
	  redBooleans[i] = true;
	  i++;
  }
  redBooleansSet = true;
}



Font pacmanFont;
Font pixelFont;
Font scoreFont;


Text scoreText;
Text topScoreText;

Sprite gameLogo;
Sprite life1;
Sprite life2;
Sprite life3;


int pelletPosX[PELLET_COUNT];
int pelletPosY[PELLET_COUNT];
bool pelletVisibility[PELLET_COUNT];
bool powerPelletStatus[POWER_PELLET_COUNT];
RectangleShape pelletShapes[PELLET_COUNT];
RectangleShape wallShapes[WALL_COUNT];
CircleShape powerpelletShapes[POWER_PELLET_COUNT];

Texture life2Texture;
Texture gameLogoTexture;
Texture life1Texture;
Texture life3Texture;


int pacmanGameMaze[GRID_HEIGHT][GRID_WIDTH] = {

    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1},
    {1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}};

int countx=0;
void RedEnemyMovement(Sprite& redEnemy) 
{
  bool ok = true;
  bool redLoopBooleans[13];
  bool movingUp = true;
  
  bool movingDown = true;
  bool movingRight = true;
  int value;
  
  int i=0;
  while(i < 13)
  {
	  redLoopBooleans[i] = true;
	  i++;
  }

  if (redBooleansSet == false)
	{
		SetRedBooleans();
	}

    
  if (movingUp && redUp)
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 360)
    {
      movingUp = false;
      redUp = false;
    }
  }
  
	bool shouldMove = !redUp && movingRight && redRight;

	if (shouldMove)
	{
		redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
		value = 210;
		if (redEnemy.getPosition().x <= value)
		{
			movingRight = false;
			redRight = false;
		}
	}

  shouldMove = (redRight == false) && movingDown && redDown;
  if (shouldMove)
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
	value = 600;
    if (redEnemy.getPosition().y >= value)
    {
	 value = 600;
      movingDown = false;
      redDown = false;
    }
  }
 
  bool shouldLoop =!redDown && redLoopBooleans[0] && redBooleans[0];
  if (shouldLoop)
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
	value = 300;
	bool loop = redEnemy.getPosition().x >= value;
    if (loop)
    {
      redBooleans[0] = false;
    }
  }
  
  shouldLoop = !redBooleans[0] && redLoopBooleans[1] && redBooleans[1];
  
  if (shouldLoop)
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 650)
    {
      redBooleans[1] = false;
    }
  }
  
  if (!redBooleans[1] && redLoopBooleans[2] && redBooleans[2])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 225)
    {
      redBooleans[2] = false;
    }
  }
  
  if (!redBooleans[2] && redLoopBooleans[3] && redBooleans[3])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 700)
    {
      redBooleans[3] = false;
    }
  }
  
  if (!redBooleans[3] && redLoopBooleans[4] && redBooleans[4])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 300)
    {
      redBooleans[4] = false;
    }
  }
  
  if (!redBooleans[4] && redLoopBooleans[5] && redBooleans[5])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 775)
    {
      redBooleans[5] = false;
    }
  }
  
  if (!redBooleans[5] && redLoopBooleans[6] && redBooleans[6])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 25)
    {
      redBooleans[6] = false;
    }
  }
  
  if (!redBooleans[6] && redLoopBooleans[7] && redBooleans[7])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 700)
    {
      redBooleans[7] = false;
    }
  }
  
  if (!redBooleans[7] && redLoopBooleans[8] && redBooleans[8])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 75)
    {
      redBooleans[8] = false;
    }
  }
  
  if (!redBooleans[8] && redLoopBooleans[9] && redBooleans[9])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 650)
    {
      redBooleans[9] = false;
    }
  }
  
  if (!redBooleans[9] && redLoopBooleans[10] && redBooleans[10])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 25)
    {
      redBooleans[10] = false;
    }
  }
  
  if (!redBooleans[10] && redLoopBooleans[11] && redBooleans[11])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 600)
    {
      redBooleans[11] = false;
    }
  }
  
  if (!redBooleans[11] && redLoopBooleans[12] && redBooleans[12])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 110) 
    {
      redBooleans[12] = false;
	  int i=0;
      while (i < 13)
      {
        redLoopBooleans[i] = true;
        redBooleans[i] = true;
		i++;
      }
    }
  }
}



void initializepelletShapes()
{
 int i=0;
  while (i < PELLET_COUNT)
  {
    pelletVisibility[i] = true;
	i++;
  }
  
  i = 0;
  while (i < PELLET_COUNT)
  {
    pelletShapes[i].setSize(Vector2f(4, 4));
    pelletShapes[i].setFillColor(Color::White);
	i++;
  }
}

void initializePowerpelletShapes()
{
    int i = 0;
    while (i < POWER_PELLET_COUNT)
    {
        powerPelletStatus[i] = false;
        i++;
    }

    i = 0;
    while (i < POWER_PELLET_COUNT)
    {
        powerpelletShapes[i].setRadius(9.0f);
        powerpelletShapes[i].setFillColor(Color(128, 128, 128));
        i++;
    }
}

bool isIntersecting(const Sprite& player, const RectangleShape& pellet)
{
	bool result;
	result = player.getGlobalBounds().intersects(pellet.getGlobalBounds());
    return result;
}

bool isIntersecting(const Sprite& player, const CircleShape& pellet)
{
	bool result;
    result = player.getGlobalBounds().intersects(pellet.getGlobalBounds());
	return result;
}

bool collidingWithPowerPellet(const Sprite& player, const CircleShape& powerPellet)
{
	bool result;
    result = player.getGlobalBounds().intersects(powerPellet.getGlobalBounds());
	return result;
}

void BlueEnemyMovement(Sprite& blueEnemy) 
{
  bool blueLoopBooleans[13];
  int i = 0;
  bool movingUp = true;
  bool movingRight = true;
  bool movingDown = true;
    
	while (i < 13)
	{
		blueLoopBooleans[i] = true;
		i++;
	}


  if (blueBooleansSet == false)
    SetBlueBooleans();
  
  if (movingUp && blueUp)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
	
    if (blueEnemy.getPosition().y <= 360)
    {
      movingUp = false;
      blueUp = false;
    }
  }
  
  bool shouldMove = (blueUp==false) && movingRight && blueRight;
  if (shouldMove)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
	int val = 460;
    if (blueEnemy.getPosition().x >= val)
    {
      movingRight = false;
      blueRight = false;
    }
  }
  
  shouldMove = (blueRight==false) && movingDown && blueDown;
  if (shouldMove)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
	int val = 600;
    if (blueEnemy.getPosition().y >= val)
    {
      movingDown = false;
      blueDown = false;
    }
  }
  
/////---------- Loop Coding ----------/////
  
  if ((blueDown==false) && blueLoopBooleans[0] && blueBooleans[0])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 650)
    {
      blueBooleans[0] = false;
    }
  }
  
  if ((blueBooleans[0]==false) && blueLoopBooleans[1] && blueBooleans[1])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 650)
    {
      blueBooleans[1] = false;
    }
  }
  
  if (!blueBooleans[1] && blueLoopBooleans[2] && blueBooleans[2])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 600)
    {
      blueBooleans[2] = false;
    }
  }
  
  if (!blueBooleans[2] && blueLoopBooleans[3] && blueBooleans[3])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 700)
    {
      blueBooleans[3] = false;
    }
  }
  
  if (!blueBooleans[3] && blueLoopBooleans[4] && blueBooleans[4])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 650)
    {
      blueBooleans[4] = false;
    }
  }
  
  if (!blueBooleans[4] && blueLoopBooleans[5] && blueBooleans[5])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 775)
    {
      blueBooleans[5] = false;
    }
  }
  
  if (!blueBooleans[5] && blueLoopBooleans[6] && blueBooleans[6])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 375)
    {
      blueBooleans[6] = false;
    }
  }
  
  if (!blueBooleans[6] && blueLoopBooleans[7] && blueBooleans[7])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 700)
    {
      blueBooleans[7] = false;
    }
  }
  
  if (!blueBooleans[7] && blueLoopBooleans[8] && blueBooleans[8])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 450)
    {
      blueBooleans[8] = false;
    }
  }
  
  if (!blueBooleans[8] && blueLoopBooleans[9] && blueBooleans[9])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 650)
    {
      blueBooleans[9] = false;
    }
  }
  
  if (!blueBooleans[9] && blueLoopBooleans[10] && blueBooleans[10])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 375)
    {
      blueBooleans[10] = false;
    }
  }
  
  if (!blueBooleans[10] && blueLoopBooleans[11] && blueBooleans[11])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 600)
    {
      blueBooleans[11] = false;
    }
  }
  
  if (!blueBooleans[11] && blueLoopBooleans[12] && blueBooleans[12])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 460)
    {
      blueBooleans[12] = false;
	  int i=0;
      while (i < 13)
      {
        blueLoopBooleans[i] = true;
        blueBooleans[i] = true;
		i++;
      }
    }
  }
}

void drawMap(RenderWindow& window, Sprite& player)
{
	int count = 0;
    int index = 0;
	int powerCount = 0;
	int size=0;
	
    RectangleShape blank(Vector2f(TILE_SIZE, TILE_SIZE));
	
    blank.setFillColor(Color::Black);
    

    
    int i = 0;
    while (i < WALL_COUNT)
    {
        wallShapes[i].setSize(Vector2f(TILE_SIZE, TILE_SIZE));
        wallShapes[i].setFillColor(Color::Blue);
        i++;
    }

    i = 0;
    while (i < GRID_HEIGHT)
    {
        int j = 0;
        while (j < GRID_WIDTH)
        {
            if (pacmanGameMaze[i][j] == 1)
            {
				size++;
                wallShapes[count].setPosition(j * TILE_SIZE, i * TILE_SIZE);
				size++;
                window.draw(wallShapes[count]);
                count++;
                
            }
            else if (pacmanGameMaze[i][j] == 0)
            {
				size++;
                if (pelletVisibility[index] == true)
                {
                  pelletShapes[index].setPosition(pelletPosX[index], pelletPosY[index]);
                  size++;
                  if (indexTracker < PELLET_COUNT)
                  {
					size++;
                    pelletPosX[indexTracker] = j * TILE_SIZE + TILE_SIZE / 2 - 2;
					size++;
                    pelletPosY[indexTracker] = i * TILE_SIZE + TILE_SIZE / 2 - 2;
                  }
                  window.draw(pelletShapes[index]);
                  indexTracker++;
				  size++;
                  index++;
                }
            }
            else if (pacmanGameMaze[i][j] == 2)
            {
				size++;
                blank.setPosition(j * TILE_SIZE + TILE_SIZE / 2 - 2, i * TILE_SIZE + TILE_SIZE / 2 - 2);
				size++;
                window.draw(blank);
            }
            else if (pacmanGameMaze[i][j] == 3)
            {
				size++;
                if (powerPelletStatus[powerCount] == false)
                {
					size++;
                  powerpelletShapes[powerCount].setPosition(j * TILE_SIZE + TILE_SIZE / 2 - 2, i * TILE_SIZE + TILE_SIZE / 2 - 2);
				  size++;
                  powerpelletShapes[powerCount].setPosition(powerpelletShapes[powerCount].getPosition().x - 5, powerpelletShapes[powerCount].getPosition().y - 7.5f);
                  size++;
				  window.draw(powerpelletShapes[powerCount]);
                }
                powerCount++;
				size++;
            }
            j++;
        }
        i++;
    }
}

void powerPelletCheck(float& movementSpeed, Clock& clock)
{
    static float actionInterval;
	actionInterval = 10.0f;	
    static bool resetClock;
	resetClock = true;
    movementSpeed = 0.4f;
	int res=0;
    float elapsedTime = clock.getElapsedTime().asSeconds();

    cout << elapsedTime << endl;

    // Check if the action interval has passed
	bool action = elapsedTime >= actionInterval;
    if (action)
    {
		res++;
        movementSpeed = 0.2f; // Change movement speed 
		res=res+2;
        powerPelletCollected = false;
    }
    else if (resetClock)
    {
        // Reset the clock only once after the interval has passed
        clock.restart();
		res++;
        resetClock = false;
		res++;
    }
}



void PlayerMove(Sprite& player, RenderWindow& window) 
{ 
     bool status;
    RectangleShape blank(Vector2f(TILE_SIZE, TILE_SIZE));
    int option = 0;
    blank.setFillColor(Color::Black);
    bool isintersect;
    
    //cout << movementSpeed << endl; 
    
    int i = 0;
    while (i < POWER_PELLET_COUNT)
    {
          isintersect =  true;
        if (isIntersecting(player, powerpelletShapes[i]))
        {
            status = powerPelletStatus[i] == false && !powerPelletCollected;
            if (status)
            {
                currentScore = currentScore + 5;
                scoreText.setString("currentScore: " + to_string(currentScore));
                powerpelletShapes[i].setFillColor(Color::Black); 
                option++;
                powerPelletStatus[i] = true;
                powerPelletCollected = true;
                option = option +1;
                loopEntered = true;
                break;
            }
        }
        i++;
    }
    
   i = 0;
    while (i < PELLET_COUNT)
    {
        if (isIntersecting(player, pelletShapes[i]))
        { 
            int j = 0;
            while (j < PELLET_COUNT)
            {
				option++;
                if (pelletShapes[i].getPosition().x == pelletPosX[j] && pelletShapes[i].getPosition().y == pelletPosY[j])
                {
					option++;
                    pelletPosX[j] = -1000;
					option++;
                    pelletPosY[j] = -1000;
                    break;
                }
                j++;
            }
        
            currentScore += 1;
            scoreText.setString("currentScore: " + to_string(currentScore)); 
            break;
        }
        i++;
    }
	
	int source=0;

    if (Keyboard::isKeyPressed(Keyboard::Left))
    {
		source=0;
        player.move(-movementSpeed, 0);
		source=0;
         int i = 0;
        while (i < WALL_COUNT)
        {
            if (isIntersecting(player, wallShapes[i]))
            {
                player.move(movementSpeed, 0);
            }
            i++;
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Right))
    {
        player.move(movementSpeed, 0);
         int i = 0;
        while (i < WALL_COUNT)
        {
            if (isIntersecting(player, wallShapes[i]))
            {
                player.move(-movementSpeed, 0);
            }
            i++;
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Up))
    {
        player.move(0, -movementSpeed);
         int i = 0;
        while (i < WALL_COUNT)
        {
            if (isIntersecting(player, wallShapes[i]))
            {
                player.move(0, movementSpeed);
            }
            i++;
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Down))
    {
        player.move(0, movementSpeed);
        int i = 0;
        while (i < WALL_COUNT)
        {
            if (isIntersecting(player, wallShapes[i]))
            {
                player.move(0, -movementSpeed);
            }
            i++;
        }
    }
}


void* StartGame(void* arg)
{
    Clock clock;
	int gameState;
	int select;
	
    playerLives = 3;
    powerPelletCollected = false;
    gameState = 0;
    select = 0;

    RenderWindow window(VideoMode(GRID_WIDTH * TILE_SIZE, GRID_HEIGHT * TILE_SIZE), "Pac-Man Game"); // 700 x 900
    
    Texture playerTexture;
    if (!playerTexture.loadFromFile("Graphics/player.png"))
    {
        cout << "Could not load player sprite" << endl;
    }
    
    Sprite player(playerTexture);
    player.setPosition(100, 450);
    player.setScale(0.045, 0.045);
    
    Texture redTexture;
    Texture pinkTexture;
    Texture greenTexture;
    Texture blueTexture;
    
    if (!redTexture.loadFromFile("Graphics/Red Enemy.png"))
    {
        cout << "Red Enemy not loaded correctly" << endl;
    }
    
    if (!pinkTexture.loadFromFile("Graphics/Pink Enemy.png"))
    {
        cout << "Pink Enemy not loaded correctly" << endl;
    }

    
    if (!greenTexture.loadFromFile("Graphics/Green Enemy.png"))
    {
        cout << "Green Enemy not loaded correctly" << endl;
    }
    
    if (!blueTexture.loadFromFile("Graphics/Blue Enemy.png"))
    {
        cout << "Blue Enemy not loaded correctly" << endl;
    }
    
    Sprite redEmemy(redTexture);
    redEmemy.setPosition(300, 450);
    redEmemy.setScale(0.25, 0.25);
    
    Sprite pinkEnemy(pinkTexture);
    pinkEnemy.setPosition(325, 450);
    pinkEnemy.setScale(0.25, 0.25);
    
    Sprite greenEmemy(greenTexture);
    greenEmemy.setPosition(350, 450);
    greenEmemy.setScale(0.25, 0.25);
    
    Sprite blueEmemy(blueTexture);
    blueEmemy.setPosition(375, 450); // [375, 450] (X = 460 till the right) && (Y = 600 till the down)
    blueEmemy.setScale(0.25, 0.25); // Loop (X = 650, Y = 650, X = 600, Y = 700, X = 650, Y = 775, X = 375, Y = 700, X = 450, Y = 650, X = 375, Y = 600, X = 460)
    
     
    

    if (!initializePellet)
    {
      initializepelletShapes();
      initializePellet = true; 
    }
    
    if (!initializePowerPellet)
    {
      initializePowerpelletShapes();
      initializePowerPellet = true;
    }

    Text playText;
    Text helpText;
    Text exitText;
  
    playText.setFont(pixelFont);
    playText.setCharacterSize(30);
    playText.setFillColor(Color::Green);
    playText.setPosition(300, 300);
    playText.setString("PLAY");
    
    helpText.setFont(pixelFont);
    helpText.setCharacterSize(30);
    helpText.setFillColor(Color::Green);
    helpText.setPosition(300, 400);
    helpText.setString("HELP");
  
    exitText.setFont(pixelFont);
    exitText.setCharacterSize(30);
    exitText.setFillColor(Color::Green);
    exitText.setPosition(300, 500);
    exitText.setString("EXIT");

    if (!gameLogoTexture.loadFromFile("Graphics/gameLogo"))
    {
      cout << "gameLogo not loaded correctly" << endl;
    }

    Sprite menugameLogo;
    menugameLogo.setTexture(gameLogoTexture);
    menugameLogo.setScale(0.075, 0.075);
    menugameLogo.setPosition(200, 0);
    
    Sprite arrow;
    Texture arrowTexture;
    
    if (!arrowTexture.loadFromFile("Graphics/Arrow 3.png"))
    {
      cout << "Arrow not loaded correctly" << endl;
    }
    
    arrow.setTexture(arrowTexture);
    arrow.setScale(0.1, 0.1);
    arrow.setPosition(225, 290);
    
    
    while (window.isOpen())
    {
    
      float time = clock.getElapsedTime().asSeconds(); 
      clock.restart();
      
      if (powerPelletCollected)
      {
        movementSpeed = 0.4;
        timer += time;
        if (timer >= 5)
        {
          movementSpeed = 0.2;
          timer = 0;
          powerPelletCollected = false;
        }
      }
    
      if (gameState == 0)
      {
        if (select == 0)
        {
          arrow.setPosition(225, 290);
        }
        else if (select == 1)
        {
          arrow.setPosition(225, 390);
        }
        else if (select == 2)
        {
          arrow.setPosition(225, 490);
        }
      
        Event selectController;
        while (window.pollEvent(selectController))
        {

          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Up)
            {
              if (select == 1)
              {
                select = 0;
              }
              else if (select == 2)
              {
                select = 1;
              }
            }
            
            if (selectController.key.code == Keyboard::Down)
            {
              if (select == 0)
              {
                select = 1;
              }
              else if (select == 1)
              {
                select = 2;
              }
            }
            
            if (selectController.key.code == Keyboard::Enter)
            {
              if (select == 0)
              {
                gameState = 1;
              }
              else if (select == 1)
              {
                gameState = 2;
              }
              else if (select == 2)
              {
                window.close();
              }
            }
          }
        }
      
        window.clear(Color::Black);
        
        window.draw(playText);
        window.draw(helpText);
        window.draw(exitText);
		
        window.draw(menugameLogo);
        window.draw(arrow);
        
        window.display();
      }
      else if (gameState == 1)
      {
        BlueEnemyMovement(blueEmemy);
        RedEnemyMovement(redEmemy);
       
        Event event;
        while (window.pollEvent(event))
        {
          if (event.type == Event::Closed)
            window.close();
        }

  int out=1;
	PlayerMove(player, window);

        window.clear(Color::Black);
      out=1;
        drawMap(window, player);
        window.draw(player);
		out=1;
        window.draw(redEmemy);
        window.draw(pinkEnemy);
		out=1;
        window.draw(greenEmemy);
        window.draw(blueEmemy);
        window.draw(scoreText);
		out=1;
        window.draw(topScoreText);
        window.draw(gameLogo);
        window.draw(life1);
		out=1;
        window.draw(life2);
        window.draw(life3);
        
        window.display();
      }  
    }
    
    pthread_exit(NULL);
}

void* SetupUI(void* arg)
{  
  int ok=0;
  if (!scoreFont.loadFromFile("Graphics/scoreFont.ttf"))
  {
    cout << "currentScore Font not loaded correctly" << endl;
  }
  ok=0;
  if (!gameLogoTexture.loadFromFile("Graphics/gameLogo"))
  {
    cout << "gameLogo not loaded correctly" << endl;
  }
  ok=0;
  if (!pacmanFont.loadFromFile("Graphics/pacman.ttf"))
  {
    cout << "Pacman Font not loaded correctly" << endl;
  }
  ok=0;
  if (!pixelFont.loadFromFile("Graphics/pixel.ttf"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  ok=0;
  if (!life1Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  ok=0;
  if (!life2Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  ok=0;
  if (!life3Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  ok=0;
  gameLogo.setTexture(gameLogoTexture);
  gameLogo.setScale(0.05, 0.05);
  gameLogo.setPosition(250, -15);
  ok=0;
  scoreText.setFont(pixelFont);
  scoreText.setCharacterSize(13);
  scoreText.setFillColor(Color::White);
  scoreText.setPosition(30, 25);
  scoreText.setString("currentScore: " + to_string(currentScore));
  ok=0;
  topScoreText.setFont(pixelFont);
  topScoreText.setCharacterSize(13);
  topScoreText.setFillColor(Color::White);
  topScoreText.setPosition(500, 25);
  topScoreText.setString("High Score: " + to_string(topScore));

  ok=0;
  life1.setTexture(life1Texture);
  life2.setTexture(life2Texture);
  life3.setTexture(life3Texture);
  ok=0;
  life1.setScale(0.07, 0.07);
  life1.setPosition(50, 840);
  ok=0;
  life2.setScale(0.07, 0.07);
  life2.setPosition(90, 840);
ok=0;
  life3.setScale(0.07, 0.07); 
  life3.setPosition(130, 840);
  ok=0;
  pthread_exit(NULL);
}

int main()
{
    pthread_t gameEngineThread;
    pthread_create(&gameEngineThread, NULL, StartGame, NULL);
    
    pthread_t userInterfaceThread;
    pthread_create(&userInterfaceThread, NULL, SetupUI, NULL);

    pthread_exit(NULL);

    return 0;
}
